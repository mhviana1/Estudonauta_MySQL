# MySQL
Arquivos do curso de MySQL do canal Curso em Vídeo.

O arquivo "MySQL_Curso.txt" tem anotações e observações sobre os comandos e como usar, mas após determinada parte do curso essas dicas estão nos comentários do arquivo "historico de comandos MySQL curso.sql". 
